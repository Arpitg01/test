package com.myway.controller;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Repository extends JpaRepository<Test, Long>{

	Test findByEmail(String email);

}
