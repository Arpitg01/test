package com.myway.controller;

import org.springframework.beans.factory.annotation.Autowired;

public class Service {

	@Autowired
	private Repository repository;
	
	
	public String checkMail(String email ) {
	
		Test test = repository.findByEmail(email);
		if(test == null) {
			return "Not found";
		}else {
			return "User Found"; 
		}
		
	}
	
	public String save(String email, String name , String phoneNo ) {
		
		Test test = repository.findByEmail(email);
		if(test == null) {
			test = new Test();
		}
		test.setEmail(email);
		test.setName(name);
		test.setPhoneNo(phoneNo);
		
		repository.save(test);
			return "Success"; 
		
		
	}
}
