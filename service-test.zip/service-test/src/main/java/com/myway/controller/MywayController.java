package com.myway.controller;

import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MywayController {

	
	@Autowired
	private Service service;
	
	@GetMapping(value="checkMail/{email}")
	public String checkEmail(@PathParam(value = "email") String email) {
		return service.checkMail(email);
	} 
	
	@PostMapping(value="save")
	public String checkEmail(@RequestBody Map<String,String> req) {
		
		return service.save(req.get("email"), req.get("name"), req.get("phoneNo") );
	} 
}
